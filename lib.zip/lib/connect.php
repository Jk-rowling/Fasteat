<?php
    class connect{
        private $host='localhost';
        private $user='root';
        private $pwd='';
        private $db='online_food';
        private $con;
        public function __construct(){
            $this->con=mysqli_connect($this->host,$this->user,$this->pwd) or die('Unable to connect with localhost');
            mysqli_select_db($this->con,$this->db) or die('Undefined Database');
        }

        public function register($name,$email,$mobile,$password)
        {
            $sql="INSERT INTO user(name,email,mobile,password)VALUES('$name','$email','$mobile','$password')";
            $n=mysqli_query($this->con,$sql);
            return $n;
        }

        public function checkDuplicateUser($email)
        {
            $sql="select * from user where email='$email'";
            $res=mysqli_query($this->con,$sql);
            $count=mysqli_num_rows($res);
            return $count;
        }
        public function login($email,$password)
        {
            $sql="select * from user where email='$email' and password='$password'";
         //   $sql="select name from user where email='$email' AND password = '$password'";
            $res=mysqli_query($this->con,$sql);
          //  $count=mysqli_num_rows($res);
          //  return $count;
            return $res;

        }
    }
?>
