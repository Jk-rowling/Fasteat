<?php
define('SITE_NAME','Food Ordering Admin');

define('SERVER_IMAGE',$_SERVER['DOCUMENT_ROOT']."//food_ordering5/");
define('SERVER_DISH_IMAGE',SERVER_IMAGE."media/dish/");

define('SITE_IMAGE',"http://localhost/food_ordering5/");
define('SITE_DISH_IMAGE',SITE_IMAGE."media/dish/");
?>