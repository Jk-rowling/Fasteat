<?php
$con=mysqli_connect('localhost','root','','online_food');
?>